import numpy as np
import pandas as pd
from vacv.core import standardize,folds,external_for_fold,features,tanimoto

def test_same_molecule_same_fold():
    d=pd.DataFrame([standardize(s) for s in ['CCO','OCC','c1ccccc1','c1ccncc1','CCC']])
    f=folds(d,'canonical_smiles')
    assert f.iloc[0]==f.iloc[1]
    assert np.array_equal(f,folds(d,'canonical_smiles'))

def test_external_exclusion():
    d=pd.DataFrame([standardize(s) for s in ['CCO','CCC','c1ccccc1','Cc1ccccc1']])
    assert len(external_for_fold(d,d.iloc[[0]],'molecule'))==3
    assert len(external_for_fold(d,d.iloc[[0]],'scaffold'))==2
    assert len(external_for_fold(d,d.iloc[[2]],'scaffold'))==2

def test_fingerprints_and_tanimoto():
    x=features(['CCO','OCC','c1ccccc1'])
    k=tanimoto(x,x)
    assert x.shape==(3,2048)
    assert np.allclose(np.diag(k),1)
    assert k[0,1]==1
