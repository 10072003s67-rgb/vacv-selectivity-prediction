import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from vacv.core import *
from scripts.download_external_data import SCHEMA

def main():
    raw=read(ROOT/'external/external_raw.csv');test=read(ROOT/'data/test_clean.csv');rows=[]
    for _,r in raw.iterrows():
        d=r.to_dict();d.update(standardize(d['smiles_raw']));notes=[];status='accepted'
        if d['structure_status']!='valid':status='review';notes.append('structure unavailable or invalid')
        if d.get('structure_verified')!='true':status='review';notes.append('measured compound identity not verified')
        if d['virus'].upper() not in ['VACV','VV','VACCINIA VIRUS']:status='rejected';notes.append('wrong virus')
        try:
            for endpoint in ['IC50','CC50']:
                unit=d[endpoint+'_unit'].replace('µ','u').replace('μ','u');v=float(d[endpoint+'_raw'])*{'nM':.001,'uM':1,'mM':1000,'M':1e6}[unit]
                if not np.isfinite(v) or v<=0:raise ValueError('invalid concentration')
                d[endpoint+'_uM']=v
                if d[endpoint+'_relation']!='=':status='review';notes.append('censored '+endpoint)
            if d['IC50_relation']==d['CC50_relation']=='=':
                d['SI_calculated']=d['CC50_uM']/d['IC50_uM'];d['SI']=d['SI_calculated']
                if d.get('SI_published') and not np.isclose(float(d['SI_published']),d['SI'],rtol=.02,atol=.05):status='review';notes.append('published SI differs beyond 2% + 0.05 rounding tolerance')
        except (ValueError,KeyError,ZeroDivisionError):status='review' if status!='rejected' else status;notes.append('invalid number or unsupported units')
        if any(not d.get(k) for k in ['source_url','IC50_locator','CC50_locator','pairing_basis','cell_line','exposure']):status='review';notes.append('missing provenance or conditions')
        if overlaps(pd.DataFrame([d]),test)[0]:status='rejected';notes.append('test structure overlap')
        d['validation_status']=status;d['validation_notes']='; '.join(notes) or 'validated exact pair';rows.append(d)
    checked=pd.DataFrame(rows)
    dup=checked.ext_id.duplicated(keep=False)
    checked.loc[dup,'validation_status']='rejected';checked.loc[dup,'validation_notes']='duplicate ext_id'
    save(checked,ROOT/'external/validation_details.csv')
    save(checked[['ext_id','validation_status','validation_notes']],ROOT/'external/validation_log.csv')
    clean=checked.loc[checked.validation_status=='accepted',SCHEMA];save(clean,ROOT/'external/external_clean.csv')
    dump({'raw':len(raw),'accepted':len(clean),'statuses':checked.validation_status.value_counts().to_dict(),'note':'No automatic acceptance from a compound-name lookup.'},ROOT/'reports/external_validation.json')
    print(checked.validation_status.value_counts().to_string())
if __name__=='__main__':main()
