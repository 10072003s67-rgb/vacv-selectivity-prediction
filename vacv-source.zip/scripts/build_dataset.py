import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from vacv.core import *

def main():
    cfg=config(); sets={}; audit={}; manifests={}
    for split in ['train','test']:
        path=ROOT/cfg[split]; raw=read(path)
        st=pd.DataFrame([standardize(s) for s in raw[cfg['smiles_column']]])
        st.insert(0,'row_id',[f'{split}:{i}' for i in range(len(raw))])
        st['competition_id']=raw[cfg['id_column']] if cfg['id_column'] in raw else ''
        if split=='train':
            st['SI']=pd.to_numeric(raw[cfg['target_column']],errors='coerce')
            st['accepted']=(st.structure_status=='valid')&np.isfinite(st.SI)&(st.SI>0)
            st['exclusion_reason']=np.where(st.accepted,'',np.where(st.structure_status!='valid','invalid structure','target must be finite and >0'))
        else:st['accepted']=True
        save(st,ROOT/f'reports/{split}_audit.csv')
        sets[split]=st.loc[st.accepted].reset_index(drop=True)
        audit[split]={'raw_rows':len(raw),'clean_rows':len(sets[split]),'invalid_structures':int((st.structure_status!='valid').sum()),'multicomponent':int(st.smiles_raw.str.contains('.',regex=False).sum())}
        manifests[split]={'path':cfg[split],'sha256':sha(path),'columns':list(raw),'bytes':path.stat().st_size}
        save(sets[split],ROOT/f'data/{split}_clean.csv')
    tr,te=sets['train'],sets['test']
    if tr.empty:raise ValueError('No valid train rows')
    audit['target']=tr.SI.describe(percentiles=[.5,.9,.95,.99]).to_dict();audit['target']['skew']=float(tr.SI.skew())
    audit['target']['equal_10000']=int((tr.SI==10000).sum());audit['train_test_exact_overlap']=int(overlaps(tr,te).sum())
    conflicts=tr.groupby('canonical_smiles').SI.agg(['count','min','max','nunique']).reset_index()
    save(conflicts[conflicts['count']>1],ROOT/'reports/duplicate_structures.csv')
    save(tr.loc[overlaps(tr,te)],ROOT/'reports/train_test_overlap.csv')
    allfolds=[];cv={}
    for scheme,key in [('molecule','canonical_smiles'),('scaffold','scaffold_key')]:
        try: f=folds(tr,key)
        except ValueError as e:cv[scheme]={'error':str(e)};continue
        d=tr[['row_id','canonical_smiles','inchikey']].copy();d.insert(0,'fold',f);d.insert(0,'scheme',scheme);d['group_key']=tr[key];allfolds.append(d)
        cv[scheme]={'n_folds':int(f.nunique()),'rows_per_fold':{str(k):int(v) for k,v in f.value_counts().sort_index().items()}}
    if not allfolds:raise ValueError('No evaluable CV')
    save(pd.concat(allfolds),ROOT/'common/folds.csv')
    dump(dict(seed=42,rdkit=rdBase.rdkitVersion,train_sha256=manifests['train']['sha256'],folds_sha256=sha(ROOT/'common/folds.csv'),schemes=cv),ROOT/'common/folds_manifest.json')
    dump(audit,ROOT/'reports/data_audit.json');dump(manifests,ROOT/'common/input_manifest.json')
    extpath=ROOT/'external/external_clean.csv'
    ext=read(extpath) if extpath.exists() else pd.DataFrame()
    if len(ext):
        ext=ext.loc[~overlaps(ext,te)&~overlaps(ext,tr)].copy()
        ext=ext.loc[~ext.canonical_smiles.duplicated(keep=False)].copy()
        ext['row_id']=ext.ext_id;ext['SI']=pd.to_numeric(ext.SI)
    tr['origin']='competition';ext['origin']='external'
    save(pd.concat([tr,ext],ignore_index=True),ROOT/'data/train_extended.csv')
    dump({'original':len(tr),'external_after_overlap_filters':len(ext),'external_training_allowed':cfg['external_data_allowed']},ROOT/'reports/extension.json')
    # Pairwise similarity audit (original structures only; no test target is read).
    good=te.structure_status=='valid'; a=features(tr.canonical_smiles);b=features(te.loc[good,'canonical_smiles'])
    sim=tanimoto(a,b);ii,jj=np.where(sim>=.9)
    save(pd.DataFrame({'train_row_id':tr.row_id.iloc[ii].to_numpy(),'test_row_id':te.loc[good,'row_id'].iloc[jj].to_numpy(),'tanimoto':sim[ii,jj]}),ROOT/'reports/similar_train_test.csv')
    print(json.dumps(audit,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
