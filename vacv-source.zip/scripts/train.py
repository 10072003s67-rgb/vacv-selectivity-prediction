import sys,time,importlib.metadata,importlib.util
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import joblib
from sklearn.metrics import mean_squared_error,mean_absolute_error
from vacv.core import *
from vacv.models import model,predict_model

def main():
    cfg=config();tr=read(ROOT/'data/train_clean.csv');te=read(ROOT/'data/test_clean.csv');ff=read(ROOT/'common/folds.csv');fm=json.loads((ROOT/'common/folds_manifest.json').read_text());inputs=json.loads((ROOT/'common/input_manifest.json').read_text())
    assert sha(ROOT/cfg['train'])==inputs['train']['sha256']==fm['train_sha256']
    assert sha(ROOT/'common/folds.csv')==fm['folds_sha256']
    y=pd.to_numeric(tr.SI).to_numpy();good=te.structure_status=='valid';cache={};results=[];runs={}
    specs=[('mean','morgan','raw',2,2048),('median','morgan','raw',2,2048)]
    for transform in ['raw','log1p']:
        for name,feat in [('ridge','morgan'),('extra','morgan'),('extra','basic'),('extra','descriptors'),('extra','combined'),('tanimoto','morgan')]+([('catboost','descriptors')] if importlib.util.find_spec('catboost') else []):specs.append((name,feat,transform,2,2048))
    specs += [('extra','morgan','raw',r,b) for r,b in [(2,1024),(2,4096),(3,1024),(3,2048),(3,4096)]]
    for scheme in ['scaffold','molecule']:
        f=pd.to_numeric(ff.loc[ff.scheme==scheme].set_index('row_id').reindex(tr.row_id).fold).to_numpy()
        assert np.isfinite(f).all();f=f.astype(int)
        for identity in ['canonical_smiles','inchikey','scaffold_key'] if scheme=='scaffold' else ['canonical_smiles','inchikey']:
            assert pd.DataFrame({'key':tr[identity],'fold':f}).groupby('key').fold.nunique().max()==1
        for name,feat,transform,r,b in specs:
            started=time.monotonic();key=(feat,r,b);tag=f'{scheme}_{name}_{feat}_{transform}_r{r}_b{b}'
            folder=ROOT/('advanced' if name=='tanimoto' else 'classical')/tag;folder.mkdir(parents=True,exist_ok=True)
            if key not in cache:cache[key]=(features(tr.canonical_smiles,*key),features(te.loc[good,'canonical_smiles'],*key))
            X,T=cache[key];oof=np.empty(len(y));scores=[]
            for k in sorted(set(f)):
                a=f!=k;v=~a;m=model(name);m.fit(X[a],np.log1p(y[a]) if transform=='log1p' else y[a]);p=predict_model(m,X[v],transform);oof[v]=p
                scores.append(dict(fold=int(k),n_rows=int(v.sum()),metric='MSE',value=mean_squared_error(y[v],p)))
            pooled=mean_squared_error(y,oof);values=[d['value'] for d in scores]
            metrics=scores+[dict(fold='pooled',n_rows=len(y),metric='MSE',value=pooled),dict(fold='mean',n_rows=len(y),metric='MSE',value=float(np.mean(values))),dict(fold='std',n_rows=len(y),metric='MSE',value=float(np.std(values)))]
            save(pd.DataFrame(dict(row_id=tr.row_id,fold=f,y_true=y,pred_si=oof)),folder/'oof.csv');save(pd.DataFrame(metrics),folder/'metrics.csv')
            m=model(name);m.fit(X,np.log1p(y) if transform=='log1p' else y);p=np.full(len(te),np.median(y));p[good]=predict_model(m,T,transform)
            save(pd.DataFrame(dict(row_id=te.row_id,pred_si=p)),folder/'test_predictions.csv')
            spec=dict(model=name,features=feat,target_transform=transform,radius=r,bits=b)
            joblib.dump(dict(model=m,spec=spec,fallback=float(np.median(y)),test_sha256=sha(ROOT/cfg['test'])),folder/'model.joblib')
            meta=dict(run_id=tag,scheme=scheme,folds_sha256=sha(ROOT/'common/folds.csv'),train_sha256=sha(ROOT/cfg['train']),test_sha256=sha(ROOT/cfg['test']),seed=42,data_variant='original',metric='MSE',metric_direction='minimize',hyperparameters={k:str(v) for k,v in m.get_params().items()},versions={n:importlib.metadata.version(n) for n in ['rdkit','numpy','pandas','scikit-learn']},training_command='python scripts/train.py',inference_command='python scripts/predict.py',**spec);dump(meta,folder/'run.json')
            results.append(dict(run_id=tag,scheme=scheme,MSE=pooled,MAE=mean_absolute_error(y,oof),fold_mean=float(np.mean(values)),fold_std=float(np.std(values)),seconds=time.monotonic()-started,**spec));runs[tag]=(folder,oof)
            save(pd.DataFrame(results),ROOT/'reports/experiments.csv');print(tag,round(pooled,3),flush=True)
    best=min([r for r in results if r['scheme']=='scaffold'],key=lambda r:r['MSE']);folder,oof=runs[best['run_id']]
    dump(dict(run_id=best['run_id'],folder=str(folder.relative_to(ROOT)),MSE=best['MSE'],selection='minimum scaffold pooled OOF MSE; selection estimate, not untouched holdout'),ROOT/'config/selected_model.json')
    errors=tr.copy();errors['y_true']=y;errors['pred_si']=oof;errors['squared_error']=(y-oof)**2;save(errors.sort_values('squared_error',ascending=False),ROOT/'reports/errors.csv')
    (ROOT/'reports/error_analysis.md').write_text(f"# Анализ ошибок\n\nВыбран {best['run_id']}. Scaffold OOF MSE: {best['MSE']:.3f}.\n\nОценка получена при выборе среди заранее заданных кандидатов, а не на независимом holdout. Доля квадратичной ошибки от 10 худших строк: {errors.nlargest(10,'squared_error').squared_error.sum()/errors.squared_error.sum():.1%}. Строки доступны только локально в errors.csv. Параметры заранее фиксированы; scaler и imputer обучаются внутри каждого фолда. Внешние данные и веса не использовались.\n")
    print('SELECTED',best,flush=True)
if __name__=='__main__':main()
