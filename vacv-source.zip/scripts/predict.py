import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import joblib
from vacv.core import *
from vacv.models import predict_model

def main():
    cfg=config();selected=json.loads((ROOT/'config/selected_model.json').read_text());folder=ROOT/selected['folder'];bundle=joblib.load(folder/'model.joblib');spec=bundle['spec']
    assert sha(ROOT/cfg['test'])==bundle['test_sha256']
    te=read(ROOT/'data/test_clean.csv');raw=read(ROOT/cfg['test']);sample=read(ROOT/cfg['sample'])
    assert len(te)==len(raw)==len(sample)
    assert list(sample)==cfg['submission_columns']
    assert sample[cfg['id_column']].tolist()==raw[cfg['id_column']].tolist()
    assert te.row_id.tolist()==[f'test:{i}' for i in range(len(raw))]
    good=te.structure_status=='valid';p=np.full(len(te),bundle['fallback']);X=features(te.loc[good,'canonical_smiles'],spec['features'],spec['radius'],spec['bits']);p[good]=predict_model(bundle['model'],X,spec['target_transform'])
    assert np.isfinite(p).all()
    assert np.allclose(p,pd.to_numeric(read(folder/'test_predictions.csv').pred_si),rtol=1e-10,atol=1e-8)
    sample[cfg['target_column']]=p;save(sample,ROOT/'submission.csv')
    dump(dict(rows=len(p),columns=list(sample),id_order_matches=True,all_finite=True,scale='original SI',reloaded_model_matches=True,sha256=sha(ROOT/'submission.csv'),run_id=selected['run_id']),ROOT/'reports/submission_validation.json')
    print('Verified submission:',len(p),'rows')
if __name__=='__main__':main()
