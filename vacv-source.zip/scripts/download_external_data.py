"""Cache public source and candidate PubChem structures; never infer a verified pairing."""
import sys,json,hashlib,csv,time
from pathlib import Path
from urllib.request import urlopen,Request
from urllib.parse import quote
from datetime import datetime,timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from vacv.core import ROOT,dump,save
import pandas as pd
SOURCE='https://pmc.ncbi.nlm.nih.gov/articles/PMC10995631/'
SCHEMA='ext_id,smiles_raw,canonical_smiles,inchikey,scaffold_key,virus,strain,assay,cell_line,exposure,IC50_raw,IC50_unit,IC50_relation,CC50_raw,CC50_unit,CC50_relation,IC50_uM,CC50_uM,SI_published,SI_published_relation,SI_calculated,SI,DOI,source,source_url,IC50_locator,CC50_locator,pairing_basis,validation_status,validation_notes'.split(',')
TABLE=[('Bufalin',.640,65.9,103),('Cinobufagin',1.24,18.8,15.2),('Convallotoxin',.573,5.72,10),('Digitoxigenin',17.9,107,6),('Digitoxin',1.72,167,97.4),('Digoxigenin',27.3,247,9),('Digoxin',4.64,65.9,14.2),('Gitoxin',33.9,267,7.9),('Lanatoside C',6.56,134,20.3),('Neriifolin',.344,28.2,82),('Ouabain',2.88,36.9,12.8),('Sarmentogenin',34.8,550,15.8)]
def main():
    cache=ROOT/'external/cache';cache.mkdir(parents=True,exist_ok=True);manifest=[]
    def fetch(url,name):
        p=cache/name
        try:
            if not p.exists():
                with urlopen(Request(url,headers={'User-Agent':'VACV-academic-data-audit/1.0'}),timeout=25) as r: p.write_bytes(r.read())
            data=p.read_bytes();manifest.append(dict(url=url,file=name,sha256=hashlib.sha256(data).hexdigest(),status='cached',accessed_utc=datetime.now(timezone.utc).isoformat()));return data
        except Exception as e:manifest.append(dict(url=url,file=name,status='failed',error=str(e)));return None
    fetch(SOURCE,'article.html');rows=[]
    for name,ic,cc,si in TABLE:
        url='https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/'+quote(name)+'/property/IsomericSMILES/JSON'
        content=fetch(url,name.replace(' ','_')+'.json');s='';cid=''
        if content:
            try:
                props=json.loads(content)['PropertyTable']['Properties']
                if len(props)==1:s=props[0].get('SMILES',props[0].get('IsomericSMILES',''));cid=str(props[0]['CID'])
            except (ValueError,KeyError):pass
        r=dict.fromkeys(SCHEMA,'');r.update(ext_id='PMC10995631:'+name,smiles_raw=s,virus='VACV',strain='Western Reserve',assay='antiviral spread / WST-1 cytotoxicity',cell_line='HeLa',exposure='24 h',IC50_raw=ic,IC50_unit='nM',IC50_relation='=',CC50_raw=cc,CC50_unit='nM',CC50_relation='=',SI_published=si,SI_published_relation='=',DOI='10.1099/jgv.0.001971',source='Samolej et al. 2024 Table 2',source_url=SOURCE,IC50_locator='Table 2 / '+name+' / IC50',CC50_locator='Table 2 / '+name+' / CC50',pairing_basis='same table and conditions (Fig 1); compound-form mapping requires review',validation_status='review',validation_notes='PubChem name lookup is candidate identity only; verify measured form and stereochemistry',compound_name=name,pubchem_cid=cid,structure_source_url=url,structure_verified='false',extraction_method='manual transcription of Table 2; structure lookup automated')
        rows.append(r);time.sleep(.25)
    save(pd.DataFrame(rows),ROOT/'external/external_raw.csv');dump(manifest,ROOT/'external/sources_manifest.json');print('Saved',len(rows),'candidate rows; identities require verification')
if __name__=='__main__':main()
