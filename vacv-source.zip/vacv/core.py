from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
from rdkit import Chem, rdBase, DataStructs
from rdkit.Chem import Descriptors, rdFingerprintGenerator
from rdkit.Chem.MolStandardize import rdMolStandardize
from rdkit.Chem.Scaffolds import MurckoScaffold
ROOT = Path(__file__).resolve().parents[1]

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(obj,path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def read(path): return pd.read_csv(path,keep_default_na=False,dtype=str)
def save(df,path):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    df.to_csv(path,index=False,lineterminator='\n')
def config(): return json.loads((ROOT/'config/competition.json').read_text())
def standardize(s):
    out=dict(smiles_raw=s,canonical_smiles='',inchikey='',scaffold_key='',structure_status='invalid',structure_notes='')
    try:
        if not isinstance(s,str) or not s.strip(): raise ValueError('empty SMILES')
        m=Chem.MolFromSmiles(s)
        if m is None or m.GetNumAtoms()==0: raise ValueError('SMILES parse failed')
        multi=len(Chem.GetMolFrags(m))>1
        m=rdMolStandardize.FragmentParent(m)
        out.update(canonical_smiles=Chem.MolToSmiles(m,canonical=True,isomericSmiles=True),inchikey=Chem.MolToInchiKey(m),scaffold_key='scaffold:'+(MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False) or 'ACYCLIC'),structure_status='valid',structure_notes='fragment parent; audit salt/form' if multi else '')
        if not out['inchikey']: raise ValueError('InChIKey failed')
    except Exception as e: out.update(structure_status='invalid',structure_notes=str(e))
    return out

def folds(df,key):
    counts=df[key].value_counts().to_dict(); k=min(5,len(counts))
    if k<2: raise ValueError(f'CV unavailable: {key} has {k} group(s)')
    sizes=[0]*k; assignment={}
    for g,n in sorted(counts.items(),key=lambda x:(-x[1],x[0])):
        f=min(range(k),key=lambda i:(sizes[i],i));assignment[g]=f;sizes[f]+=n
    result=df[key].map(assignment).astype(int)
    for identity in ['canonical_smiles','inchikey']:
        if pd.DataFrame({'key':df[identity],'fold':result}).groupby('key').fold.nunique().max()>1:
            raise ValueError('Identity inconsistency: revise shared grouping contract')
    return result

def overlaps(a,b):
    mask=np.zeros(len(a),dtype=bool)
    for col in ['smiles_raw','canonical_smiles','inchikey']:
        mask |= a[col].isin(set(b[col])-{''}).to_numpy()
    return mask

def external_for_fold(ext,valid,scheme):
    mask=overlaps(ext,valid)
    if scheme=='scaffold': mask |= ext.scaffold_key.isin(valid.scaffold_key).to_numpy()
    return ext.loc[~mask].copy()

def features(smiles,kind='morgan',radius=2,bits=2048):
    gen=rdFingerprintGenerator.GetMorganGenerator(radius=radius,fpSize=bits,includeChirality=True)
    names=[n for n,_ in Descriptors._descList]
    basic=['MolWt','MolLogP','TPSA','NumHDonors','NumHAcceptors','NumRotatableBonds','RingCount','FractionCSP3']
    desc=dict(Descriptors._descList); rows=[]
    for s in smiles:
        m=Chem.MolFromSmiles(s) if s else None
        fp=np.zeros(bits,dtype=np.float64)
        if m: DataStructs.ConvertToNumpyArray(gen.GetFingerprint(m),fp)
        if kind=='morgan':rows.append(fp);continue
        vals=[]
        for name in (basic if kind=='basic' else names):
            try: value=desc[name](m) if m else np.nan
            except Exception:value=np.nan
            vals.append(value if np.isfinite(value) else np.nan)
        rows.append(np.r_[fp,vals] if kind=='combined' else vals)
    return np.array(rows,dtype=float)

def tanimoto(a,b):
    inter=a@b.T; union=a.sum(1)[:,None]+b.sum(1)[None,:]-inter
    return np.divide(inter,union,out=np.zeros_like(inter),where=union!=0)
