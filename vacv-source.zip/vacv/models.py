import numpy as np
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.kernel_ridge import KernelRidge
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.dummy import DummyRegressor
from vacv.core import tanimoto
class TanimotoRidge(RegressorMixin,BaseEstimator):
    def __init__(self,alpha=1.): self.alpha=alpha
    def fit(self,X,y):
        self.X_=X.copy();self.model_=KernelRidge(alpha=self.alpha,kernel='precomputed').fit(tanimoto(X,X),y);return self
    def predict(self,X):return self.model_.predict(tanimoto(X,self.X_))
def model(name):
    if name=='mean':return DummyRegressor(strategy='mean')
    if name=='median':return DummyRegressor(strategy='median')
    if name=='tanimoto':return TanimotoRidge()
    if name=='ridge':reg=Ridge(alpha=100)
    elif name=='extra':reg=ExtraTreesRegressor(n_estimators=200,min_samples_leaf=3,max_features=.7,random_state=42,n_jobs=2)
    elif name=='catboost':
        from catboost import CatBoostRegressor
        reg=CatBoostRegressor(iterations=300,depth=4,learning_rate=.04,l2_leaf_reg=10,loss_function='RMSE',random_seed=42,thread_count=2,verbose=False,allow_writing_files=False)
    else:raise ValueError(name)
    steps=[SimpleImputer(strategy='median',keep_empty_features=True)]
    if name=='ridge':steps.append(StandardScaler())
    return make_pipeline(*steps,reg)
def predict_model(m,X,transform):
    p=m.predict(X)
    if transform=='log1p':p=np.expm1(p)
    p=np.maximum(p,0)
    if not np.isfinite(p).all():raise ValueError('Nonfinite prediction')
    return p
